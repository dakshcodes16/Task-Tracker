import React from 'react';
import TaskItem from './TaskItem';
import { ListFilter, CheckCircle, ClipboardList } from 'lucide-react';

export default function TaskList({ tasks, activeFilter, onToggleStatus, onDeleteTask }) {
  const getFilterLabel = () => {
    if (activeFilter === 'All') return 'All Tasks';
    if (activeFilter === 'Completed') return 'Completed Tasks';
    return 'Pending Tasks';
  };

  return (
    <div className="space-y-3">
      {/* Subheader banner showing Current View (from Assessment Page 4 screenshot) */}
      <div className="flex items-center justify-between text-xs sm:text-sm font-medium text-slate-500 bg-slate-50/80 px-3 py-2 rounded-lg border border-slate-200/60">
        <div className="flex items-center gap-2">
          <ListFilter className="w-4 h-4 text-blue-600" />
          <span>
            Current View: <strong className="text-slate-700">{getFilterLabel()}</strong>
          </span>
        </div>
        <span className="text-xs text-slate-500">
          {tasks.length} {tasks.length === 1 ? 'task' : 'tasks'}
        </span>
      </div>

      {/* Task List or Empty State */}
      {tasks.length === 0 ? (
        <div
          id="tasks-empty-state"
          className="text-center py-10 px-4 bg-slate-50/50 rounded-xl border border-dashed border-slate-300"
        >
          <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-3 text-slate-400">
            {activeFilter === 'Completed' ? (
              <CheckCircle className="w-6 h-6 text-slate-400" />
            ) : (
              <ClipboardList className="w-6 h-6 text-slate-400" />
            )}
          </div>
          <p className="text-sm font-semibold text-slate-700 mb-1">
            {activeFilter === 'Completed'
              ? 'No completed tasks yet'
              : activeFilter === 'Pending'
              ? 'No pending tasks left!'
              : 'No tasks to show'}
          </p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            {activeFilter === 'Completed'
              ? 'Check off tasks from your list as you finish them.'
              : activeFilter === 'Pending'
              ? 'Great job! You have cleared all your pending work.'
              : 'Type a task in the box above and click "Add Task" to get started.'}
          </p>
        </div>
      ) : (
        <div className="space-y-2.5" id="task-items-container">
          {tasks.map((task) => (
            <TaskItem
              key={task.id}
              task={task}
              onToggleStatus={onToggleStatus}
              onDeleteTask={onDeleteTask}
            />
          ))}
        </div>
      )}
    </div>
  );
}
