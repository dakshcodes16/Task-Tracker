import React from 'react';
import { RotateCcw, Trash } from 'lucide-react';

export default function Footer({ onResetDemo, onClearCompleted, completedCount }) {
  return (
    <footer className="mt-8 pt-4 border-t border-slate-200/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
      <div className="flex items-center gap-1.5">
        <span>Press <kbd className="px-1.5 py-0.5 bg-slate-100 border border-slate-300 rounded text-[10px] font-mono text-slate-700">Enter</kbd> to quickly add tasks</span>
      </div>

      <div className="flex items-center gap-3">
        {completedCount > 0 && (
          <button
            type="button"
            onClick={onClearCompleted}
            className="hover:text-red-600 transition-colors flex items-center gap-1 cursor-pointer"
            title="Remove all completed tasks"
          >
            <Trash className="w-3.5 h-3.5" />
            <span>Clear Completed</span>
          </button>
        )}

        <button
          type="button"
          onClick={onResetDemo}
          className="hover:text-blue-600 transition-colors flex items-center gap-1 cursor-pointer"
          title="Reset to default sample tasks"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Sample Tasks</span>
        </button>
      </div>
    </footer>
  );
}
