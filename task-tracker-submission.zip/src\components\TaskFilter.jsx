import React from 'react';
import { CloudCheck, Check } from 'lucide-react';

export default function TaskFilter({ activeFilter, onFilterChange, counts }) {
  const filters = [
    { key: 'All', label: 'All', count: counts.all },
    { key: 'Pending', label: 'Pending', count: counts.pending },
    { key: 'Completed', label: 'Completed', count: counts.completed },
  ];

  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 mb-4 border-b border-slate-200">
      {/* Filter Buttons */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs sm:text-sm font-semibold text-slate-600 mr-1">
          Filter by:
        </span>
        <div className="inline-flex p-1 bg-slate-100 rounded-xl border border-slate-200/80">
          {filters.map((filter) => {
            const isActive = activeFilter === filter.key;
            return (
              <button
                key={filter.key}
                id={`filter-btn-${filter.key.toLowerCase()}`}
                type="button"
                onClick={() => onFilterChange(filter.key)}
                className={`relative px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all duration-200 flex items-center gap-1.5 cursor-pointer ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm font-semibold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/70'
                }`}
              >
                <span>{filter.label}</span>
                <span
                  className={`text-[11px] px-1.5 py-0.2 rounded-full font-semibold ${
                    isActive
                      ? 'bg-blue-700/80 text-white'
                      : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {filter.count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Auto-saving Status Indicator (from Assessment Page 4) */}
      <div
        id="auto-save-indicator"
        className="flex items-center gap-1.5 text-xs text-slate-500 bg-slate-50 px-2.5 py-1 rounded-full border border-slate-200/80"
        title="Tasks are automatically stored in browser localStorage"
      >
        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
        <span className="text-slate-600 font-medium">Auto-saving enabled</span>
      </div>
    </div>
  );
}
