import React from 'react';
import { Trash2, Check } from 'lucide-react';

export default function TaskItem({ task, onToggleStatus, onDeleteTask }) {
  const isCompleted = task.status === 'Completed';

  return (
    <div
      id={`task-item-${task.id}`}
      className={`group flex items-center justify-between gap-3 p-3.5 sm:p-4 rounded-xl border transition-all duration-200 ${
        isCompleted
          ? 'bg-slate-50/60 border-slate-200 hover:bg-slate-50'
          : 'bg-white border-slate-200/90 hover:border-blue-200 hover:shadow-sm'
      }`}
    >
      {/* Left section: Checkbox + Text */}
      <div className="flex items-center gap-3.5 min-w-0 flex-1">
        {/* Custom Checkbox button */}
        <button
          type="button"
          role="checkbox"
          aria-checked={isCompleted}
          id={`task-checkbox-${task.id}`}
          onClick={() => onToggleStatus(task.id)}
          className={`shrink-0 w-5 h-5 rounded-md flex items-center justify-center transition-all duration-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-1 ${
            isCompleted
              ? 'bg-blue-600 text-white border border-blue-600 shadow-sm'
              : 'border-2 border-slate-300 hover:border-blue-500 bg-white'
          }`}
          title={isCompleted ? 'Mark as Pending' : 'Mark as Completed'}
        >
          {isCompleted && <Check className="w-3.5 h-3.5 stroke-[3]" />}
        </button>

        {/* Task Text */}
        <span
          onClick={() => onToggleStatus(task.id)}
          className={`text-sm sm:text-base cursor-pointer select-none truncate transition-all duration-200 ${
            isCompleted
              ? 'text-slate-400 line-through decoration-slate-400'
              : 'text-slate-800 font-medium'
          }`}
          title={task.text}
        >
          {task.text}
        </span>
      </div>

      {/* Right section: Status badge + Delete button */}
      <div className="flex items-center gap-2.5 shrink-0">
        {/* Status Pill Badge */}
        <span
          id={`task-badge-${task.id}`}
          className={`inline-flex items-center px-2.5 py-0.8 rounded-full text-xs font-semibold tracking-wide transition-all ${
            isCompleted
              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
              : 'bg-amber-50 text-amber-700 border border-amber-200'
          }`}
        >
          {task.status}
        </span>

        {/* Delete button (Red Trash Can) */}
        <button
          type="button"
          id={`task-delete-${task.id}`}
          onClick={() => onDeleteTask(task.id)}
          aria-label={`Delete task: ${task.text}`}
          title="Delete task"
          className="p-1.5 rounded-lg text-red-500 hover:text-red-700 hover:bg-red-50 active:bg-red-100 transition-colors duration-150 cursor-pointer focus:outline-none focus:ring-2 focus:ring-red-300"
        >
          <Trash2 className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
        </button>
      </div>
    </div>
  );
}
