# JTRONIX Frontend Internship Assessment: Task Tracker

A responsive, modern, and attractive **Task Tracker** web application built with **React** (functional components and hooks) and **Tailwind CSS**. The application runs entirely client-side in the browser without any backend server or database, persisting all data and status changes using browser `localStorage`.

---

## 🚀 Live Demo & Running Locally

### Prerequisites
- Node.js (v18+ or v20+ recommended)
- npm (v9+ or v10+)

### Setup Instructions
1. Navigate to the project root directory:
   ```bash
   cd task-tracker
   ```
2. Install all dependencies:
   ```bash
   npm install
   ```
3. Start the Vite local development server:
   ```bash
   npm run dev
   ```
4. Open your browser and navigate to:
   ```text
   http://localhost:5173/
   ```

### Production Build
To create an optimized production build:
```bash
npm run build
npm run preview
```

---

## 📋 Features Implemented (Assessment Compliance)

### 1.1 Create and Display Tasks
- **Task Input Field:** Clean, accessible text box with placeholder `"Enter a new task..."`.
- **Primary Action Button:** Styled blue `"Add Task"` button with micro-interaction hover and click effects.
- **Task List Rendering:** Real-time display of added tasks with status badges and checkboxes.
- **Input Validation:** Prevents submission of empty strings or whitespace-only inputs, displaying an inline warning alert and visual border highlight.

### 1.2 Manage Tasks
- **Status Toggling:** Interactive custom checkbox on the far left to switch each task between `'Completed'` and `'Pending'`.
- **Dynamic Task Text Styling:** Automatically applies a sleek strikethrough line and muted grey text color when a task is marked `'Completed'`.
- **Status Badges:** Pill-shaped badges reflecting current status:
  - `Completed`: Light green text with matching soft green border and background (`bg-emerald-50 text-emerald-700`).
  - `Pending`: Light orange text with matching soft orange border and background (`bg-amber-50 text-amber-700`).
- **Task Deletion:** Red trash can icon on the far right allowing users to delete individual tasks instantly.
- **Statistics Dashboard:** Dedicated metrics row showing:
  - **Total Tasks:** Count of all tasks in the list.
  - **Completed:** Total completed tasks styled in green.
  - **Pending:** Total pending tasks styled in yellow/amber.
  - **Progress Bar:** Real-time completion percentage visual bar.

### 1.3 Filter and Save Tasks
- **Filter Criteria:** Toggle button group with real-time badges to filter by:
  - **All**
  - **Pending**
  - **Completed**
- **Active Filter Highlight:** Currently active filter is emphasized with high-contrast primary blue background and bold styling.
- **Current View Banner:** Dynamic subheader bar indicating the active filter and item counts (`Current View: Completed Tasks`).
- **Persistent Storage:** Integrated browser `localStorage` to automatically save tasks upon any change (add, toggle, delete) and rehydrate state seamlessly after a page reload or refresh.
- **Visual Persistence Indicator:** Includes the `"Auto-saving enabled"` pulsing status badge matching the design specifications.
- **Responsive Layout:** Optimized with Tailwind CSS for mobile, tablet, and desktop viewports with responsive grid, flexible typography, and touch-friendly controls.

---

## 🏗️ Project Architecture & Components

```text
task-tracker/
├── index.html                  # HTML entry point with Inter font & metadata
├── package.json                # Dependencies and project scripts
├── tailwind.config.js          # Tailwind CSS theme & content configuration
├── postcss.config.js           # PostCSS setup
├── vite.config.js              # Vite bundler configuration
├── screenshots/                # Application verification screenshots
│   ├── initial_task_tracker_*.png
│   ├── validation_error_*.png
│   ├── task_added_*.png
│   ├── filter_pending_*.png
│   ├── filter_completed_*.png
│   ├── filter_all_*.png
│   ├── task_completed_*.png
│   ├── task_deleted_*.png
│   └── persistence_verified_*.png
└── src/
    ├── main.jsx                # React root bootstrap
    ├── index.css               # Tailwind CSS directives & base styles
    ├── App.jsx                 # Top-level state, localStorage sync, handlers
    └── components/
        ├── Header.jsx          # Dark blue nav bar with checkmark icon
        ├── TaskInput.jsx       # Input field, Add button, validation alert
        ├── TaskStats.jsx       # Dashboard statistics row & progress bar
        ├── TaskFilter.jsx      # Filter buttons & auto-save indicator
        ├── TaskList.jsx        # Current view subheader banner & list container
        ├── TaskItem.jsx        # Checkbox, strikethrough text, badge, delete button
        └── Footer.jsx          # Quick shortcuts & demo reset action
```

---

## 💾 LocalStorage Schema
Each task is stored as a JSON object within `localStorage` under key `'jtronix_task_tracker_data'`:
```typescript
interface Task {
  id: string;        // Unique identifier (timestamp string)
  text: string;      // Task description
  status: 'Completed' | 'Pending'; // Current task status
}
```

---

## 🛠️ Tech Stack
- **Framework:** React 18 (Functional Components, `useState`, `useEffect`)
- **Styling:** Tailwind CSS v3
- **Icons:** Lucide React
- **Build Tool:** Vite v8
- **Typography:** Inter (via Google Fonts)
