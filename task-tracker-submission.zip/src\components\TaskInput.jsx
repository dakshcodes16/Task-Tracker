import React, { useState } from 'react';
import { PlusCircle, AlertCircle } from 'lucide-react';

export default function TaskInput({ onAddTask }) {
  const [taskText, setTaskText] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const trimmed = taskText.trim();
    if (!trimmed) {
      setErrorMessage('Task cannot be empty. Please enter a valid task description.');
      return;
    }
    onAddTask(trimmed);
    setTaskText('');
    setErrorMessage('');
  };

  const handleChange = (e) => {
    setTaskText(e.target.value);
    if (errorMessage) {
      setErrorMessage('');
    }
  };

  return (
    <div className="mb-6">
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <input
            id="task-input-field"
            type="text"
            value={taskText}
            onChange={handleChange}
            placeholder="Enter a new task..."
            aria-label="New task description"
            className={`w-full px-4 py-3 rounded-xl border ${
              errorMessage
                ? 'border-red-400 focus:ring-red-200 focus:border-red-500'
                : 'border-slate-300 focus:ring-blue-100 focus:border-blue-500'
            } text-slate-800 placeholder-slate-400 bg-slate-50/50 focus:bg-white text-sm sm:text-base transition-all duration-200 outline-none focus:ring-4 shadow-inner`}
          />
        </div>
        <button
          id="add-task-btn"
          type="submit"
          className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold text-sm sm:text-base shadow-sm hover:shadow-md transition-all duration-200 transform active:scale-95 focus:outline-none focus:ring-4 focus:ring-blue-200 cursor-pointer"
        >
          <PlusCircle className="w-5 h-5" />
          <span>Add Task</span>
        </button>
      </form>

      {/* Validation feedback */}
      {errorMessage && (
        <div
          id="task-input-error"
          role="alert"
          className="mt-2.5 flex items-center gap-2 text-xs sm:text-sm text-red-600 bg-red-50/80 border border-red-200 px-3 py-2 rounded-lg transition-all animate-fadeIn"
        >
          <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
          <span>{errorMessage}</span>
        </div>
      )}
    </div>
  );
}
