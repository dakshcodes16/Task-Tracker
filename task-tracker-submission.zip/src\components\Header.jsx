import React from 'react';
import { CheckSquare, Sparkles } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-blue-600 text-white shadow-md">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-lg bg-white/15 border border-white/30 flex items-center justify-center shadow-inner">
            <CheckSquare className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
              Task Tracker
            </h1>
          </div>
        </div>
        <div className="flex items-center gap-2 text-xs font-medium text-blue-100 bg-blue-700/60 px-3 py-1.5 rounded-full border border-blue-400/30">
          <Sparkles className="w-3.5 h-3.5 text-blue-200" />
          <span className="hidden sm:inline">JTRONIX Frontend Assessment</span>
          <span className="sm:hidden">v1.3</span>
        </div>
      </div>
    </header>
  );
}
