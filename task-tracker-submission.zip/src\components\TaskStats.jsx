import React from 'react';
import { Layers, CheckCircle2, Clock } from 'lucide-react';

export default function TaskStats({ total, completed, pending }) {
  const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0;

  return (
    <div className="mb-6">
      <div className="grid grid-cols-3 gap-3 sm:gap-4">
        {/* Total Tasks Card */}
        <div
          id="stat-total-tasks"
          className="bg-slate-50 border border-slate-200/80 rounded-xl p-3 sm:p-4 text-center transition-all duration-200 hover:border-slate-300 hover:shadow-sm"
        >
          <div className="flex items-center justify-center gap-1.5 text-slate-500 text-xs sm:text-sm font-medium mb-1">
            <Layers className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-slate-400" />
            <span>Total Tasks</span>
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-slate-800 tracking-tight">
            {total}
          </div>
        </div>

        {/* Completed Tasks Card */}
        <div
          id="stat-completed-tasks"
          className="bg-emerald-50/50 border border-emerald-100 rounded-xl p-3 sm:p-4 text-center transition-all duration-200 hover:border-emerald-200 hover:shadow-sm"
        >
          <div className="flex items-center justify-center gap-1.5 text-emerald-700 text-xs sm:text-sm font-medium mb-1">
            <CheckCircle2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-600" />
            <span>Completed</span>
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-emerald-600 tracking-tight">
            {completed}
          </div>
        </div>

        {/* Pending Tasks Card */}
        <div
          id="stat-pending-tasks"
          className="bg-amber-50/50 border border-amber-100 rounded-xl p-3 sm:p-4 text-center transition-all duration-200 hover:border-amber-200 hover:shadow-sm"
        >
          <div className="flex items-center justify-center gap-1.5 text-amber-700 text-xs sm:text-sm font-medium mb-1">
            <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-500" />
            <span>Pending</span>
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-amber-500 tracking-tight">
            {pending}
          </div>
        </div>
      </div>

      {/* Completion Progress Bar */}
      {total > 0 && (
        <div className="mt-3 px-1">
          <div className="flex justify-between items-center text-xs text-slate-500 mb-1">
            <span>Overall Progress</span>
            <span className="font-semibold text-slate-700">{completionRate}%</span>
          </div>
          <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-blue-500 to-emerald-500 transition-all duration-500 ease-out rounded-full"
              style={{ width: `${completionRate}%` }}
            />
          </div>
        </div>
      )}
    </div>
  );
}
