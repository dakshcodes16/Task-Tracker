import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import TaskInput from './components/TaskInput';
import TaskStats from './components/TaskStats';
import TaskFilter from './components/TaskFilter';
import TaskList from './components/TaskList';
import Footer from './components/Footer';

// Default initial tasks matching the assessment sample
const DEFAULT_TASKS = [
  { id: '1', text: 'Complete project documentation', status: 'Completed' },
  { id: '2', text: 'Prepare for team meeting', status: 'Pending' },
  { id: '3', text: 'Fix login issue', status: 'Completed' },
  { id: '4', text: 'Design new feature', status: 'Pending' },
  { id: '5', text: 'Write test cases', status: 'Pending' },
];

const LOCAL_STORAGE_KEY = 'jtronix_task_tracker_data';

export default function App() {
  // 1. Core State Initialization with localStorage Persistence
  const [tasks, setTasks] = useState(() => {
    try {
      const savedTasks = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (savedTasks !== null) {
        return JSON.parse(savedTasks);
      }
    } catch (error) {
      console.error('Failed to load tasks from localStorage:', error);
    }
    return DEFAULT_TASKS;
  });

  // Filter state: 'All' | 'Pending' | 'Completed'
  const [filter, setFilter] = useState('All');

  // Temporary feedback toast state
  const [toastMessage, setToastMessage] = useState('');

  // Persist tasks to browser localStorage whenever tasks state changes
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(tasks));
    } catch (error) {
      console.error('Failed to save tasks to localStorage:', error);
    }
  }, [tasks]);

  // Helper for quick toast alert
  const showToast = (message) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage('');
    }, 2500);
  };

  // Add Task handler
  const handleAddTask = (text) => {
    const newTask = {
      id: Date.now().toString(),
      text,
      status: 'Pending',
    };
    setTasks((prevTasks) => [newTask, ...prevTasks]);
    showToast(`Added: "${text}"`);
  };

  // Toggle Task Status ('Completed' <-> 'Pending')
  const handleToggleStatus = (id) => {
    setTasks((prevTasks) =>
      prevTasks.map((task) => {
        if (task.id === id) {
          const nextStatus = task.status === 'Completed' ? 'Pending' : 'Completed';
          return { ...task, status: nextStatus };
        }
        return task;
      })
    );
  };

  // Delete Task handler
  const handleDeleteTask = (id) => {
    const taskToDelete = tasks.find((t) => t.id === id);
    setTasks((prevTasks) => prevTasks.filter((task) => task.id !== id));
    if (taskToDelete) {
      showToast(`Deleted: "${taskToDelete.text}"`);
    }
  };

  // Reset demo tasks handler
  const handleResetDemo = () => {
    setTasks(DEFAULT_TASKS);
    setFilter('All');
    showToast('Reset to default sample tasks');
  };

  // Clear completed tasks handler
  const handleClearCompleted = () => {
    const completedCount = tasks.filter((t) => t.status === 'Completed').length;
    setTasks((prevTasks) => prevTasks.filter((t) => t.status !== 'Completed'));
    showToast(`Cleared ${completedCount} completed tasks`);
  };

  // 4. Statistics Calculation
  const totalCount = tasks.length;
  const completedCount = tasks.filter((t) => t.status === 'Completed').length;
  const pendingCount = tasks.filter((t) => t.status === 'Pending').length;

  // 6. Filtered Tasks Calculation
  const filteredTasks = tasks.filter((task) => {
    if (filter === 'Completed') return task.status === 'Completed';
    if (filter === 'Pending') return task.status === 'Pending';
    return true; // 'All'
  });

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans">
      {/* 2. Dark Blue Top Navigation Bar */}
      <Header />

      {/* Main Content Area */}
      <main className="flex-1 py-8 sm:py-12 px-4 sm:px-6 flex items-start justify-center">
        {/* Centrally aligned white card container */}
        <div className="w-full max-w-2xl bg-white rounded-2xl shadow-xl shadow-slate-200/70 border border-slate-200/80 p-5 sm:p-8 transition-all">
          {/* Card Subheading */}
          <div className="mb-5 pb-3 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-800">My Task Dashboard</h2>
              <p className="text-xs sm:text-sm text-slate-500">
                Organize, track, and accomplish your daily workflow
              </p>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 bg-blue-50 text-blue-700 rounded-full border border-blue-200/60">
              Browser Storage
            </span>
          </div>

          {/* 3. Input Section (Create Tasks) */}
          <TaskInput onAddTask={handleAddTask} />

          {/* 4. Statistics Section (Manage Tasks) */}
          <TaskStats
            total={totalCount}
            completed={completedCount}
            pending={pendingCount}
          />

          {/* 5. Filter Section */}
          <TaskFilter
            activeFilter={filter}
            onFilterChange={setFilter}
            counts={{
              all: totalCount,
              pending: pendingCount,
              completed: completedCount,
            }}
          />

          {/* 6. Task List Display */}
          <TaskList
            tasks={filteredTasks}
            activeFilter={filter}
            onToggleStatus={handleToggleStatus}
            onDeleteTask={handleDeleteTask}
          />

          {/* Quick Actions Footer */}
          <Footer
            onResetDemo={handleResetDemo}
            onClearCompleted={handleClearCompleted}
            completedCount={completedCount}
          />
        </div>
      </main>

      {/* Interactive Toast Notification */}
      {toastMessage && (
        <div
          id="toast-notification"
          role="status"
          className="fixed bottom-6 right-6 z-50 bg-slate-900/90 backdrop-blur-md text-white text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-2 animate-bounce"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
